from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.models import BktMasteryEvent, LearnerLessonMastery
from app.schemas.mastery import MasteryEventCreate, MasteryEventResponse, ParametersUsed
from app.services.bkt_math import mastery_level, update_mastery
from app.services.parameter_service import resolve_parameters


def _response_from_event(
    event: BktMasteryEvent,
    mastery: LearnerLessonMastery,
    *,
    duplicate: bool,
) -> MasteryEventResponse:
    params = event.parameters_used
    return MasteryEventResponse(
        source_event_id=event.source_event_id,
        duplicate=duplicate,
        learner_id=event.learner_id,
        lesson_id=event.lesson_id,
        question_id=event.question_id,
        is_correct=event.is_correct,
        predicted_correct_probability=event.predicted_correct_probability,
        mastery_before=event.mastery_before,
        mastery_posterior=event.mastery_posterior,
        mastery_after=event.mastery_after,
        mastery_level=mastery.mastery_level,
        attempt_count=mastery.attempt_count,
        parameters_used=ParametersUsed(**params),
        processed_at=event.processed_at,
    )


def process_mastery_event(session: Session, payload: MasteryEventCreate) -> MasteryEventResponse:
    existing_event = session.scalar(
        select(BktMasteryEvent).where(
            BktMasteryEvent.source_event_id == payload.source_event_id
        )
    )
    if existing_event:
        mastery = session.get(
            LearnerLessonMastery,
            (existing_event.learner_id, existing_event.lesson_id),
        )
        if mastery is None:
            raise RuntimeError("Mastery event exists but its mastery row is missing")
        return _response_from_event(existing_event, mastery, duplicate=True)

    settings = get_settings()
    parameters = resolve_parameters(
        session,
        lesson_id=payload.lesson_id,
        difficulty_level=payload.difficulty_level,
        assessment_type=payload.assessment_type,
    )

    mastery = session.scalar(
        select(LearnerLessonMastery)
        .where(
            LearnerLessonMastery.learner_id == payload.learner_id,
            LearnerLessonMastery.lesson_id == payload.lesson_id,
        )
        .with_for_update()
    )
    mastery_before = mastery.mastery_probability if mastery else parameters.prior
    update = update_mastery(
        mastery_before=mastery_before,
        is_correct=payload.is_correct,
        learn=parameters.learn,
        guess=parameters.guess,
        slip=parameters.slip,
        forget=parameters.forget,
    )
    level = mastery_level(
        update.mastery_after,
        developing_threshold=settings.developing_threshold,
        good_threshold=settings.good_threshold,
        mastered_threshold=settings.mastered_threshold,
    )
    now = datetime.now(timezone.utc)

    if mastery is None:
        mastery = LearnerLessonMastery(
            learner_id=payload.learner_id,
            lesson_id=payload.lesson_id,
            mastery_probability=update.mastery_after,
            mastery_level=level,
            attempt_count=1,
            last_event_id=payload.source_event_id,
            last_updated=now,
        )
        session.add(mastery)
    else:
        mastery.mastery_probability = update.mastery_after
        mastery.mastery_level = level
        mastery.attempt_count += 1
        mastery.last_event_id = payload.source_event_id
        mastery.last_updated = now

    event = BktMasteryEvent(
        source_event_id=payload.source_event_id,
        learner_id=payload.learner_id,
        lesson_id=payload.lesson_id,
        question_id=payload.question_id,
        is_correct=payload.is_correct,
        difficulty_level=payload.difficulty_level,
        assessment_type=payload.assessment_type,
        mastery_before=update.mastery_before,
        mastery_posterior=update.mastery_posterior,
        mastery_after=update.mastery_after,
        predicted_correct_probability=update.predicted_correct_probability,
        parameters_used=parameters.as_dict(),
        occurred_at=payload.occurred_at,
        processed_at=now,
    )
    session.add(event)

    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        existing_event = session.scalar(
            select(BktMasteryEvent).where(
                BktMasteryEvent.source_event_id == payload.source_event_id
            )
        )
        if existing_event is None:
            raise
        mastery = session.get(
            LearnerLessonMastery,
            (existing_event.learner_id, existing_event.lesson_id),
        )
        if mastery is None:
            raise RuntimeError("Duplicate event exists without mastery row")
        return _response_from_event(existing_event, mastery, duplicate=True)

    session.refresh(event)
    session.refresh(mastery)
    return _response_from_event(event, mastery, duplicate=False)
